document.getElementById('bottle').onclick = function() {
    let answer = confirm("Devons-nous laisser cette bouteille ici ?");
    let resultText = "";

    if (answer) {
        resultText = "<strong>Effet :</strong> Vous avez décidé de laisser la bouteille ici !<br><strong>Explication :</strong> Laisser des déchets peut nuire à la faune et à la flore et contribuer à la pollution.";
    } else {
        resultText = "<strong>Effet :</strong> Vous avez décidé de ramasser la bouteille !<br><strong>Explication :</strong> En ramassant les déchets, vous aidez à garder notre planète propre et à protéger l'environnement.";
    }

    document.getElementById('result').innerHTML = resultText;
};
